<?php $__env->startSection('mainbody'); ?>

		<!-- BREADCRUMB -->
		<div id="breadcrumb" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-12">
						<ul class="breadcrumb-tree">
							<li><a href="#">Home</a></li>
							<li><a href="#"> <?php echo e($category->cat_name); ?></a></li>
						</ul>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /BREADCRUMB -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<!-- ASIDE -->
					<?php echo $__env->make('frontend.includes.pruduct_sidebar_widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<!-- /ASIDE -->
<?php if(count($products) > 0): ?>

					<!-- STORE -->
					<div id="store" class="col-md-9">
						<!-- store top filter -->
						<!-- <div class="store-filter clearfix">
							<div class="store-sort">
								<label>
									Sort By:
									<select class="input-select">
										<option value="0">Popular</option>
										<option value="1">Position</option>
									</select>
								</label>

								<label>
									Show:
									<select class="input-select">
										<option value="0">20</option>
										<option value="1">50</option>
									</select>
								</label>
							</div>
							<ul class="store-grid">
								<li class="active"><i class="fa fa-th"></i></li>
								<li><a href="#"><i class="fa fa-th-list"></i></a></li>
							</ul>
						</div> -->
						<!-- /store top filter -->

						<!-- store products -->
						<div class="row">
							<!-- product -->
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-4 col-xs-6">
								<div class="product">
									<a href="<?php echo e(route('single.product',$product->id)); ?>">
									<div class="product-img">
										<img src="<?php echo e(asset('uploads/product/'.$product->p_image)); ?>" alt="" height="250" >
										<div class="product-label">
											<?php if($product->discount_percentage > 0): ?>
											<span class="sale"><?php echo e($product->discount_percentage); ?>%</span>
											<?php endif; ?>
											<?php if(now()->diffInDays($product->created_at) < 3): ?>
											<span class="new">NEW</span>
											<?php endif; ?>											
										</div>
									</div>
									<div class="product-body">
										<p class="product-category"><?php echo e($product->category->cat_name); ?></p>
										<h3 class="product-name"><a href="<?php echo e(route('single.product',$product->id)); ?>"><?php echo e(Illuminate\Support\Str::limit($product->p_name,50,'....')); ?></a></h3>
										<h4 class="product-price" style="padding: 5px 0;">&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($product->p_price); ?></del></h4>
										<div class="product-rating">
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
										</div>
										<div class="product-btns">
											<form style="display: inline"  action="<?php echo e(route('product.add_to_wishlist')); ?>" method="POST">
												<?php echo csrf_field(); ?>
													<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
													<?php if(Auth::user()): ?>

														
	
														<?php if(App\Models\CartWishlist::where('p_id',$product->id)->where('user_id', Auth::user()->id)->first()): ?>
														<button disabled  class="add-to-wishlist" style="background: none; border:none;"><i style="color:red;" class="fa fa-heart"></i><span class="tooltipp">add to wishlist</span></button>

														<?php else: ?>
														<button  class="add-to-wishlist" style="background: none; border:none;"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
														<?php endif; ?>
													<?php else: ?>
													<button  class="add-to-wishlist" style="background: none; border:none;"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
													<?php endif; ?>											
												</form>											
												<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
												<button class="quick-view" value="<?php echo e($product->id); ?>" data-toggle="modal" data-target="#productModal"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button>
											</div>
									</div>
									</a>
									<form action="<?php echo e(route('product.add_to_cart')); ?>" method="POST">
										<?php echo csrf_field(); ?>
									<div class="add-to-cart">
										<input type="hidden" name="quantity" value="1">
										<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
										<?php if($product->p_qty != 0): ?>
										<button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to cart</button>
										<?php else: ?>
										<span class="product-available " style="color:white;">Stock Out</span>
										<?php endif; ?>									</div>
									</form>
								</div>
							</div>
							<!-- /product -->
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						</div>

						<!-- /store products -->

						<!-- store bottom filter -->
						<div class="store-filter clearfix">
							<span class="store-qty">Showing <?php echo e($products->firstItem()); ?> - <?php echo e($products->lastItem()); ?> products</span>
							
							<div class="store-pagination">
								<div class="custom-pagination">
									<div class="pagination">
										
										<?php if($products->onFirstPage()): ?>
											<span class="disabled">Previous</span>
										<?php else: ?>
											<a href="<?php echo e($products->previousPageUrl()); ?>" rel="prev">Previous</a>
										<?php endif; ?>
								
										
										<?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
											<?php if($i == $products->currentPage()): ?>
												<span class="current"><?php echo e($i); ?></span>
											<?php else: ?>
												<a href="<?php echo e($products->url($i)); ?>"><?php echo e($i); ?></a>
											<?php endif; ?>
										<?php endfor; ?>
								
										
										<?php if($products->hasMorePages()): ?>
											<a href="<?php echo e($products->nextPageUrl()); ?>" rel="next">Next</a>
										<?php else: ?>
											<span class="disabled">Next</span>
										<?php endif; ?>
									</div>
								</div>
				
							</div>
						</div>
						<!-- /store bottom filter -->
					</div>
					<!-- /STORE -->
<?php else: ?>
<h4 class="text-center">Empty this category product item </h4>
<?php endif; ?>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->
		

<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/frontend/page/category_product.blade.php ENDPATH**/ ?>