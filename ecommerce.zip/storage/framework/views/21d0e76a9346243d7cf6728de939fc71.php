<footer class="main-footer">
        <div class="footer-left">
          <a href="#">All rights reserved <?php echo e($siteInfo->name); ?> </a></a>
        </div>
        <div class="footer-right">
        </div>
</footer><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/backend/includes/footer.blade.php ENDPATH**/ ?>