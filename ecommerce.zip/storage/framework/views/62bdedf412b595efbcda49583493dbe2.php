<?php $__env->startComponent('mail::message'); ?>;
<p>Hello <?php echo e($user['name']); ?> </p>
<p><?php echo e($user->remember_token); ?> </p>
<?php $__env->startComponent('mail::button',['url'=> url('reset_password',$user->remember_token)]); ?>
    Reset your password
<?php echo $__env->renderComponent(); ?>

<p>Incase you have you have anyissues recovering your password, please contact us.</p>

Thanks <br>
<?php echo e(config('app.name')); ?>


<?php echo $__env->renderComponent(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/mails/forget_mail_msg.blade.php ENDPATH**/ ?>