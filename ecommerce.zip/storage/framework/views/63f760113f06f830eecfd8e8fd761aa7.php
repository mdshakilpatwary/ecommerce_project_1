<?php $__env->startComponent('mail::message'); ?>;
<?php
use App\Models\IncludeAnother;
use App\Models\Order;
use App\Models\OrderDatails;

    $order= Order::findOrFail($orderId);
    $orderIds= OrderDatails::where('order_id',$orderId)->get();


?>
<h4 class="display-3">Order Id- <?php echo e($order->order_invoice_id); ?> </h4>
<p>Hello <?php echo e($user_id->name); ?> </p>
<hr>
<hr>
<div class="" style="display: flex; align-content:space-between;">
    <p>
        <strong>Billed To:</strong><br>
        <?php echo e($order->customer->name); ?><br>
    
    </p>
    <p >
        <strong>Shipped To:</strong><br>
        Name: <?php echo e($order->shipping->name); ?><br>
        Email: <?php echo e($order->shipping->email); ?><br>
        Phone: <?php echo e($order->shipping->phone); ?> <br>
        Address: <?php echo e($order->shipping->address); ?><br>
        <?php echo e($order->shipping->city); ?>,<?php echo e($order->shipping->country); ?>

            
    </p>
</div>
<hr>
<div class="" style="display: flex; align-content: space-between">
    <address>
        <strong>Payment Method:</strong><br>
        <?php echo e($order->payment->paymentMethod); ?><br>
        <?php echo e($order->shipping->email); ?>

      </address>
      <address>
        <strong>Order Date:</strong><br>
        <?php echo e($order->created_at->format('M d,y-  h:iA')); ?><br><br>
      </address>
</div>
<hr>
<p class="section-title">Order Summary</p>
<table class="table table-striped table-hover table-md">
    <tbody>
      <tr>
          <th data-width="40" style="width: 40px;">#</th>
          <th>Product Name</th>
          <th class="text-center">Color</th>
          <th class="text-center">Size</th>
          <th class="text-center">Price</th>
          <th class="text-center">Quantity</th>
          <th class="text-right">Totals</th>
      </tr>
      <?php
      $sl =1;
      ?>
      <?php $__currentLoopData = $orderIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td><?php echo e($sl++); ?></td>
          <td><?php echo e($data->product_name); ?></td>
          <td class="text-center"><?php echo e(($data->product_color != null) ?$data->product_color : 'None'); ?></td>
          <td class="text-center"><?php echo e(($data->product_size != null) ?$data->product_size : 'None'); ?></td>
          <td class="text-center">&#2547; <?php echo e($data->product_price); ?></td>
          <td class="text-center"><?php echo e($data->product_sale_qty); ?></td>
          <td class="text-right"> &#2547; <?php echo e($data->product_price * $data->product_sale_qty); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>

  <hr>
  <p class="invoice-detail-item " style="float: right">

    <span class="invoice-detail-name">Subtotal</span>
    <span class="invoice-detail-value">&#2547; <?php echo e($order->total -$order->delivery_charge); ?></span>
  </p>
  <hr class="clearfix">
  <p class="invoice-detail-item " style="float: right">
    <span class="invoice-detail-name ">Shipping</span>
    <?php if($order->delivery_charge == 0): ?>
    <div class="invoice-detail-value">Free</div>
    <?php else: ?>
    <div class="invoice-detail-value">&#2547; <?php echo e($order->delivery_charge); ?></div>
    <?php endif; ?>
  </p>
  
  <hr class="mt-2 mb-2 clearfix">
  <p class="invoice-detail-item " style="float: right">
    <span class="invoice-detail-name">Total</span>
    <span class="invoice-detail-value invoice-detail-value-lg">&#2547;<?php echo e($order->total); ?></span>
  </p>
  <p class="clearfix"></p>


Thanks <br>
<?php echo e(config('app.name')); ?>


<?php echo $__env->renderComponent(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/mails/order_invoice_mail_msg.blade.php ENDPATH**/ ?>