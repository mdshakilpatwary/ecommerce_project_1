<?php $__env->startSection('maincontent'); ?>
<div class="row mt-2">
<?php if(session('success')): ?>

<div class="container alertsuccess">
  <div class="alert alert-success alert-dismissible show fade">
      <div class="alert-body">
        <button class="close" data-dismiss="alert">
          <span>×</span>
        </button>
        <?php echo e(session('success')); ?>

      </div>
  </div>
</div>
<?php elseif(session('error')): ?>
<div class="container alerterror">
  <div class="alert alert-success alert-dismissible show fade">
      <div class="alert-body">
        <button class="close" data-dismiss="alert">
          <span>×</span>
        </button>
        <?php echo e(session('error')); ?>

      </div>
  </div>
</div>

<?php endif; ?>
</div>

<div class="row">
  <div class="col-md-12">   
    <h2>Add Product Offer Deal Content </h2>
  </div>
  <div class="col-md-8 offset-md-2 rounded py-3" style="background: #fff; box-shadow: 0 0 8px #ddd">
      
<?php if(App\Models\OfferDealContent::all() != null): ?>
<form action="<?php echo e(route('offer.content.store')); ?>" method="POST" >
  <?php echo csrf_field(); ?>
  <div class="row " >
      <div class="form-group col-md-6 col-xl-6 col-12">
        <label for="offer_heading">Offer Heading </label>
        <input type="text" name="offer_heading" class="form-control" id="offer_heading">
        <?php $__errorArgs = ['offer_heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger "><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group col-md-6 col-xl-6 col-12">
          <label for="offer_content">Offer Content </label>
          <input type="text" name="offer_content" class="form-control" id="offer_content">
          <?php $__errorArgs = ['offer_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger "><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      
      <div class="form-group col-md-6 col-xl-6 col-12">
          <label for="offer_start_date">Offer Start Date </label>
          <input type="date" name="offer_start_date" class="form-control" id="offer_start_date">
          <?php $__errorArgs = ['offer_start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger "><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group col-md-6 col-xl-6 col-12">
          <label for="offer_end_date">Offer End Date </label>
          <input type="date" name="offer_end_date" class="form-control" id="offer_end_date">
          <?php $__errorArgs = ['offer_end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger "><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group col-md-6 col-xl-6 col-12">
          <label for="offerimage1">Offer Content Image 01  </label>
          <input type="file" name="offerimage1" class="form-control" id="offerimage1">
          <?php $__errorArgs = ['offerimage1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger "><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group col-md-6 col-xl-6 col-12">
          <label for="offerimage2">Offer Content Image 02  </label>
          <input type="file" name="offerimage2" class="form-control" id="offerimage2">
          <?php $__errorArgs = ['offerimage2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger "><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      
      
      <div class="col-md-12 col-xl-12 col-12">
        <button class="btn btn-lg btn-success">Submit</button>
      </div>  </div>
</form>
<?php else: ?>
<form action="<?php echo e(route('offer.content.store')); ?>" method="POST" >
  <?php echo csrf_field(); ?>
  <div class="row">
      <div class="form-group col-md-6 col-xl-6 col-12">
        <label for="offer_heading">Offer Heading </label>
        <input type="text" name="offer_heading" class="form-control" id="offer_heading">
        <?php $__errorArgs = ['offer_heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger "><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group col-md-6 col-xl-6 col-12">
          <label for="offer_content">Offer Content </label>
          <input type="text" name="offer_content" class="form-control" id="offer_content">
          <?php $__errorArgs = ['offer_content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger "><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      
      <div class="form-group col-md-6 col-xl-6 col-12">
          <label for="offer_start_date">Offer Start Date </label>
          <input type="date" name="offer_start_date" class="form-control" id="offer_start_date">
          <?php $__errorArgs = ['offer_start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger "><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group col-md-6 col-xl-6 col-12">
          <label for="offer_end_date">Offer End Date </label>
          <input type="date" name="offer_end_date" class="form-control" id="offer_end_date">
          <?php $__errorArgs = ['offer_end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger "><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group col-md-6 col-xl-6 col-12">
          <label for="offerimage1">Offer Content Image 01  </label>
          <input type="file" name="offerimage1" class="form-control" id="offerimage1">
          <?php $__errorArgs = ['offerimage1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger "><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <div class="form-group col-md-6 col-xl-6 col-12">
          <label for="offerimage2">Offer Content Image 02  </label>
          <input type="file" name="offerimage2" class="form-control" id="offerimage2">
          <?php $__errorArgs = ['offerimage2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="text-danger "><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      
      <div class="col-md-12 col-xl-12 col-12">
        <button class="btn btn-lg btn-success">Update</button>
      </div>
  </div>
</form>
<?php endif; ?>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/backend/offerContent/index.blade.php ENDPATH**/ ?>