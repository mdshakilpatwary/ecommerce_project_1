<div class="main-sidebar sidebar-style-2 pb-5">
        <aside id="sidebar-wrapper ">
          <div class="sidebar-brand">
            <?php if($siteInfo->main_logo == ''): ?>
            <a href="<?php echo e(route('admin.dashboard')); ?>"> <img alt="image" src="<?php echo e(asset('backend')); ?>/assets/img/logo.png" class="header-logo" /> <span
                class="logo-name"><?php echo e($siteInfo->name); ?></span>
            </a>
            <?php else: ?>
            <a href="<?php echo e(route('admin.dashboard')); ?>"> <img alt="image" src="<?php echo e(asset('uploads/info/'.$siteInfo->main_logo)); ?>" class="header-logo" /> <span
                class="logo-name"><?php echo e($siteInfo->name); ?></span>
            </a>
            <?php endif; ?>
          </div>
          <ul class="sidebar-menu pb-5">

            <li class="menu-header">Main</li>
            <li class="dropdown <?php echo e(Route::is('create.product*') || Route::is('admin.dashboard*') ? 'active' : ''); ?>">
              <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>
            
            <li class="dropdown ">
              <a href="<?php echo e(route('frontend_site')); ?>" target="blank" class="nav-link"><i data-feather="server"></i><span>View site</span></a>
            </li>
          <?php if(Auth::user()->can('admin.create') || Auth::user()->can('admin.view')): ?>

            <li class="menu-header">User Elements</li>
            <li class="dropdown <?php echo e(Route::is('user.create*') || Route::is('user.manage*') || Route::is('user.edit*') ? 'active' : ''); ?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i class="fas fa-user"></i><span>User</span></a>
              <ul class="dropdown-menu">
                <?php if(Auth::user()->can('admin.create')): ?>
                <li><a class="nav-link" href="<?php echo e(route('user.create')); ?>">User Create</a></li>
                <?php endif; ?>
                <?php if(Auth::user()->can('admin.view')): ?>
                <li><a class="nav-link" href="<?php echo e(route('user.manage')); ?>">User Manage</a></li>
                <?php endif; ?>
                
              </ul>
            </li>
          <?php endif; ?>

          <?php if(Auth::user()->can('product.view') || Auth::user()->can('product.create')): ?>
            <li class="menu-header">Product Elements</li>
            <li class="dropdown <?php echo e(Route::is('create.product*') || Route::is('show.product*') || Route::is('edit.product*') ? 'active' : ''); ?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i class="fas fa-store"></i><span>Product</span></a>
              <ul class="dropdown-menu">
                <?php if( Auth::user()->can('product.create')): ?>
                <li><a class="nav-link" href="<?php echo e(route('create.product')); ?>">Add Product</a></li>
                <?php endif; ?>
                <li><a class="nav-link" href="<?php echo e(route('show.product')); ?>">Manage Product</a></li>
              </ul>
            </li>
            <?php if( Auth::user()->can('product.create')): ?>
            <li class="dropdown <?php echo e(Route::is('create.catagory*') || Route::is('show.catagory*') || Route::is('edit.catagory*') ? 'active' : ''); ?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="layers"></i><span>Category</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="<?php echo e(route('create.catagory')); ?>">Add Category</a></li>
                <li><a class="nav-link" href="<?php echo e(route('show.catagory')); ?>">Manage Category</a></li>
              </ul>
            </li>
            <li class="dropdown <?php echo e(Route::is('create.subcatagory*') || Route::is('show.subcatagory*') || Route::is('edit.subcatagory*') ? 'active' : ''); ?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="layers"></i><span>Sub Category</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="<?php echo e(route('create.subcatagory')); ?>">Add Sub Category</a></li>
                <li><a class="nav-link" href="<?php echo e(route('show.subcatagory')); ?>">Manage Sub Category</a></li>
              </ul>
            </li>
            <li class="dropdown <?php echo e(Route::is('create.brand*') || Route::is('show.brand*') || Route::is('edit.brand*') ? 'active' : ''); ?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="layers"></i><span>Brand</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="<?php echo e(route('create.brand')); ?>">Add Brand</a></li>
                <li><a class="nav-link" href="<?php echo e(route('show.brand')); ?>">Manage Brand</a></li>
              </ul>
            </li>
            <li class="dropdown <?php echo e(Route::is('create.size*') || Route::is('show.size*') || Route::is('edit.size*') ? 'active' : ''); ?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="layers"></i><span>Size</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="<?php echo e(route('create.size')); ?>">Add Size</a></li>
                <li><a class="nav-link" href="<?php echo e(route('show.size')); ?>">Manage Size</a></li>
              </ul>
            </li>
            <li class="dropdown <?php echo e(Route::is('create.color*') || Route::is('show.color*') || Route::is('edit.color*') ? 'active' : ''); ?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i data-feather="layers"></i><span>Color</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="<?php echo e(route('create.color')); ?>">Add Color</a></li>
                <li><a class="nav-link" href="<?php echo e(route('show.color')); ?>">Manage Color</a></li>
              </ul>
            </li>
            <?php endif; ?>
          <?php endif; ?>
            <?php if(Auth::user()->can('order.view')): ?>

              <li class="menu-header">Customer Order Elements</li>
              <li class="dropdown <?php echo e(Route::is('order.product*') || Route::is('order.product.details*') || Route::is('order.order.invoice*') ? 'active' : ''); ?>">
                <a href="#" class="menu-toggle nav-link has-dropdown"><i class="fas fa-box"></i><span>Customer Order</span></a>
                <ul class="dropdown-menu">
                  <li><a class="nav-link" href="<?php echo e(route('order.product')); ?>">Customer Order</a></li>
                  
                </ul>
              </li>

            <?php endif; ?>
            <?php if(Auth::user()->can('role.create') || Auth::user()->can('role.view')): ?>

            <li class="menu-header">Role and Permission Elements</li>
            <li class="dropdown <?php echo e(Route::is('role.permission.create*') || Route::is('role.permission.manage*') || Route::is('role.permission.edit*') ? 'active' : ''); ?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i class="fas fa-cogs"></i><span>Role and Permission</span></a>
              <ul class="dropdown-menu">
                <?php if(Auth::user()->can('role.create')): ?>
                <li><a class="nav-link" href="<?php echo e(route('role.permission.create')); ?>">Role Create</a></li>
                <?php endif; ?>
                <?php if(Auth::user()->can('role.view')): ?>
                <li><a class="nav-link" href="<?php echo e(route('role.permission.manage')); ?>">Role Manage</a></li>
                <?php endif; ?>
              </ul>
            </li>
            <?php endif; ?>
            

            <li class="menu-header">Offer Elements</li>
            <li class="dropdown <?php echo e(Route::is('offer.content*')? 'active' : ''); ?>">
              <a href="<?php echo e(route('offer.content')); ?>" class="nav-link"><i class="fas fa-puzzle-piece"></i><span>Offer Content</span></a>
            </li>
          
            <?php if(Auth::user()->can('admin.create') || Auth::user()->can('admin.view')): ?>

            <li class="menu-header">Additional Setting Elements</li>
            <li class="dropdown <?php echo e(Route::is('include.another.create*')? 'active' : ''); ?>">
              <a href="<?php echo e(route('include.another.create')); ?>" class="nav-link"><i class="fas fa-puzzle-piece"></i><span>Additional Setting</span></a>
            </li>
          <?php endif; ?>

            



          

          </ul>
        </aside>
      </div><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/backend/includes/sidebar.blade.php ENDPATH**/ ?>