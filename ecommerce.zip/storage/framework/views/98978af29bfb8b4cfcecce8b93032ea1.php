<?php $__env->startSection('mainbody'); ?>
	<!-- BREADCRUMB -->
<div id="breadcrumb" class="section">
	<input type="hidden" id="single_product_id" value="<?php echo e($product->id); ?>">
    <!-- container -->
    <div class="container">
        <!-- row -->
        <div class="row">
            <div class="col-md-12">
                <ul class="breadcrumb-tree">
                    <li><a href="#">Home</a></li>
                    <li><a href="#"><?php echo e($product->category->cat_name); ?></a></li>
                    <li><a href="#"><?php echo e($product->subcategory->subcat_name); ?></a></li>
                    <li class="active"><?php echo e($product->p_name); ?></li>
                </ul>
            </div>
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</div>
<!-- /BREADCRUMB -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<!-- Product main img -->
					<div class="col-md-5 col-md-push-2">
						<div id="product-main-img">
							<!-- multiple img show  -->
							
							
							
							 <?php $__currentLoopData = explode('|',$product->group_p_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="product-preview">
								<img src="<?php echo e(asset('uploads/product/product_group/'.$group_image)); ?>" alt="">
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							
							
						</div>
					</div>
					<!-- /Product main img -->

					<!-- Product thumb imgs -->
					<div class="col-md-2  col-md-pull-5">
						<div id="product-imgs">
							<?php $__currentLoopData = explode('|',$product->group_p_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group_image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="product-preview">
								<img src="<?php echo e(asset('uploads/product/product_group/'.$group_image)); ?>" alt="">
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						
						</div>
					</div>
					<!-- /Product thumb imgs -->

					<!-- Product details -->
					<div class="col-md-5">
						<div class="product-details">
							<h2 class="product-name"><?php echo e($product->p_name); ?></h2>
							<div>
								<?php if($product->discount_percentage > 0): ?>
									<span class="bg-success">Discount <?php echo e($product->discount_percentage); ?>%</span>
								<?php else: ?>
								<span class="bg-warning ">No Discount</span>
								<?php endif; ?>
								<br class="mb-3">
								<?php if(now()->diffInDays($product->created_at) < 3): ?>
								<span class="new">NEW</span>
								<?php endif; ?>	
								<div class="product-rating">
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<i class="fa fa-star"></i>
									<span id="review_count_top" style="font-weight: 600; color:gray"></span>
								</div>
							</div>
							<div>
								<h3 class="product-price">&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($product->p_price); ?></del></h3>
								<?php if($product->p_qty != 0): ?>
								<span class="product-available">In Stock</span>
								<?php endif; ?>
							</div>
							<p><?php echo e($product->short_description); ?></p>
							<form action="<?php echo e(route('product.add_to_cart')); ?>" method="POST">
								<?php echo csrf_field(); ?>

							<div class="product-options">
								<label>
									<?php if($product->size_id != null): ?>
									Size
									<?php else: ?>
									Kg/Liter
									<?php endif; ?>
									<select class="input-select" name="size">
										<?php if($product->size_id != null): ?>
										<?php $__currentLoopData = explode("|",$product->size_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>										
										<option value="<?php echo e($size); ?>"><?php echo e($size); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php else: ?>
										<?php $__currentLoopData = explode("|",$product->kg_liter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>										
										<option value="<?php echo e($kg); ?>"><?php echo e($kg); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</select>
								</label>
								<label>
									Color

									<select class="input-select" name="color">
										<?php $__currentLoopData = explode("|",$product->color_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($color); ?>"><?php echo e($color); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								</label>
							</div>
							<?php if($product->p_qty != 0): ?>
							<div class="add-to-cart">
								<div class="qty-label">
									Qty
									<div class="input-number">
										<input type="number" name="quantity" value="1" >
										<span class="qty-up">+</span>
										<span class="qty-down">-</span>
									</div>
									<?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger pt-1"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
								<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

								<button  class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> Add To Cart</button>
								
							</div>
							<?php else: ?>
							<div class="add-to-cart">
								<div class="qty-label">
									Qty
									<div class="input-number">
										<input type="number" name="quantity" class="quantity" value="1">
										<span class="qty-up">+</span>
										<span class="qty-down">-</span>
									</div>
									<?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
									<p class="text-danger pt-1"><?php echo e($message); ?></p>
									<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
								</div>
								<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

								<button disabled class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> Stock Out</button>
								
							</div>
							<?php endif; ?>
							</form>

							<ul class="product-btns">
								<form style="display: inline"  action="<?php echo e(route('product.add_to_wishlist')); ?>" method="POST">
									<?php echo csrf_field(); ?>
										<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
									<?php if(Auth::user()): ?>
									
										<?php if(App\Models\CartWishlist::where('p_id',$product->id)->where('user_id', Auth::user()->id)->first()): ?>
										<li><a ><button  disabled style="background: none; border:none;"><i class="fa fa-heart"></i> ADD TO WISHLIST</button></a></li>

										<?php else: ?>
										<li><a ><button style="background: none; border:none;"><i class="fa fa-heart-o"></i> ADD TO WISHLIST</button></a></li>
										<?php endif; ?>
									<?php else: ?>
									<li><a ><button style="background: none; border:none;"><i class="fa fa-heart-o"></i> ADD TO WISHLIST</button></a></li>

									<?php endif; ?>
									</form>
								<li><a href="#"><i class="fa fa-exchange"></i> add to compare</a></li>
							</ul>

							<ul class="product-links">
								<li>Category:</li>
								<li><a href="#"><?php echo e($product->category->cat_name); ?></a></li>
								<li><a href="#"><?php echo e($product->subcategory->subcat_name); ?></a></li>
							</ul>

							<ul class="product-links">
								<li>Share:</li>
								<li><a href="#"><i class="fa fa-facebook"></i></a></li>
								<li><a href="#"><i class="fa fa-twitter"></i></a></li>
								<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
								<li><a href="#"><i class="fa fa-envelope"></i></a></li>
							</ul>

						</div>
					</div>
					<!-- /Product details -->

					<!-- Product tab -->
					<div class="col-md-12">
						<div id="product-tab">
							<!-- product tab nav -->
							<ul class="tab-nav">
								<li class="active"><a data-toggle="tab" href="#tab1">Description</a></li>
								<li><a data-toggle="tab" href="#tab2">Details</a></li>
								<li><a data-toggle="tab" href="#tab3">Reviews <span id="review_count"></span></a></li>
							</ul>
							<!-- /product tab nav -->

							<!-- product tab content -->
							<div class="tab-content">
								<!-- tab1  -->
								<div id="tab1" class="tab-pane fade in active">
									<div class="row">
										<div class="col-md-12">
											<p><?php echo $product->p_description; ?></p>
										</div>
									</div>
								</div>
								<!-- /tab1  -->

								<!-- tab2  -->
								<div id="tab2" class="tab-pane fade in">
									<div class="row">
										<div class="col-md-12">
											<?php if($product->p_details == ''): ?>
											<p class="text-center">No details here</p>
											<?php else: ?>
											<p><?php echo e($product->p_details); ?></p>
											<?php endif; ?>
										</div>
									</div>
								</div>
								<!-- /tab2  -->

								<!-- tab3  -->
								<div id="tab3" class="tab-pane fade in">
									<div class="row">
										<!-- Rating -->
										<div class="col-md-3">
											<div id="rating">
												<div class="rating-avg">
													<span>4.5</span>
													<div class="rating-stars">
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star"></i>
														<i class="fa fa-star-o"></i>
													</div>
												</div>
												<ul class="rating">
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
														</div>
														<div class="rating-progress">
															<div style="width: 80%;"></div>
														</div>
														<span class="sum">3</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div style="width: 60%;"></div>
														</div>
														<span class="sum">2</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div></div>
														</div>
														<span class="sum">0</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div></div>
														</div>
														<span class="sum">0</span>
													</li>
													<li>
														<div class="rating-stars">
															<i class="fa fa-star"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
															<i class="fa fa-star-o"></i>
														</div>
														<div class="rating-progress">
															<div></div>
														</div>
														<span class="sum">0</span>
													</li>
												</ul>
											</div>
										</div>
										<!-- /Rating -->

										<!-- Reviews -->
										<div class="col-md-6">
											<div id="reviews">
												<ul class="reviews" id="public_review_part">
												</ul>
							
												<ul class="reviews-pagination review_pagination">
													
												</ul>
									
											</div>
										</div>
										<!-- /Reviews -->

										<!-- Review Form -->
										<div class="col-md-3">
											<div id="review-form">
												<p class="insert_success bg-success " style="margin-bottom: 8px;"></p>
												<div class="insert_error bg-danger " style="margin-bottom: 8px;"></div>
												<div class="review-form" id="reviewInsertForm" >
													
												<?php if(Auth::user()): ?>
													<?php if(App\Models\ProductReview::where('user_id',Auth::user()->id)->where('product_id',$product->id)->first() != true): ?>
													
													<input type="hidden" id="review_product_id" value="<?php echo e($product->id); ?>">
													<input class="input" type="text" id="review_name" placeholder="Your Name">
													<?php $__errorArgs = ['review_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<p class="text-danger "><?php echo e($message); ?></p>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													<input class="input" type="email" id="review_email" placeholder="Your Email">
													<?php $__errorArgs = ['review_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<p class="text-danger "><?php echo e($message); ?></p>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													<textarea class="input" id="review" placeholder="Your Review"></textarea>
													<?php $__errorArgs = ['review'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
														<p class="text-danger "><?php echo e($message); ?></p>
													<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
													<div class="input-rating">
														<span>Your Rating: </span>
														<div class="stars">
															<input id="star5" name="review_rating" value="5" type="radio"><label for="star5"></label>
															<input id="star4" name="review_rating" value="4" type="radio"><label for="star4"></label>
															<input id="star3" name="review_rating" value="3" type="radio"><label for="star3"></label>
															<input id="star2" name="review_rating" value="2" type="radio"><label for="star2"></label>
															<input id="star1" name="review_rating" value="1" type="radio"><label for="star1"></label>
															<?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
																<p class="text-danger "><?php echo e($message); ?></p>
															<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
														</div>
														
													</div>
													<button class="primary-btn" onclick="reviewInsert()">Submit</button>
													<?php else: ?>
													<p>Already your review done</p>
													<?php endif; ?>

												<?php else: ?>
													<input class="input" type="text" id="review_name" placeholder="Your Name">
				
													<input class="input" type="email" id="review_email" placeholder="Your Email">
													<textarea class="input" id="review" placeholder="Your Review"></textarea>
													<div class="input-rating">
														<span>Your Rating: </span>
														<div class="stars">
															<input id="star5" name="review_rating" value="5" type="radio"><label for="star5"></label>
															<input id="star4" name="review_rating" value="4" type="radio"><label for="star4"></label>
															<input id="star3" name="review_rating" value="3" type="radio"><label for="star3"></label>
															<input id="star2" name="review_rating" value="2" type="radio"><label for="star2"></label>
															<input id="star1" name="review_rating" value="1" type="radio"><label for="star1"></label>
														</div>
														
													</div>
													<a href="<?php echo e(route('login')); ?>" class="primary-btn" >Submit</a>
												<?php endif; ?>
												</div>
											</div>
										</div>
										<!-- /Review Form -->
									</div>
								</div>
								<!-- /tab3  -->
							</div>
							<!-- /product tab content  -->
						</div>
					</div>
					<!-- /product tab -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- Section -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

					<div class="col-md-12">
						<div class="section-title text-center">
							<h3 class="title">Related Products</h3>
						</div>
					</div>


					<!-- product -->
					<?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-md-3 col-xs-6">
						<div class="product">
							<a href="<?php echo e(route('single.product',$r_product->id)); ?>">
							<div class="product-img">
								<img src="<?php echo e(asset('uploads/product/'.$r_product->p_image)); ?>" alt="" height="250">
								<div class="product-label">
									<?php if($r_product->discount_percentage > 0): ?>
									<span class="sale"><?php echo e($r_product->discount_percentage); ?>%</span>
									<?php endif; ?>
									<!-- <span class="new">NEW</span> -->								</div>
							</div>
							<div class="product-body">
								<p class="product-category"><?php echo e($r_product->category->cat_name); ?></p>
								<h3 class="product-name  " ><a href="<?php echo e(route('single.product',$r_product->id)); ?>"><?php echo e(Illuminate\Support\Str::limit($r_product->p_name,50,'....')); ?></a></h3>
								<h4 class="product-price" style="padding: 5px 0;">&#2547;<?php echo e($r_product->p_price -($r_product->p_price*($r_product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($r_product->p_price); ?></del></h4>
								<div class="product-rating">
								</div>
								<div class="product-btns">
									<form style="display: inline"  action="<?php echo e(route('product.add_to_wishlist')); ?>" method="POST">
										<?php echo csrf_field(); ?>
											<input type="hidden" name="product_id" value="<?php echo e($r_product->id); ?>">
											<?php if(Auth::user()): ?>

												

												<?php if(App\Models\CartWishlist::where('p_id',$r_product->id)->where('user_id', Auth::user()->id)->first()): ?>
												<button disabled  class="add-to-wishlist" style="background: none; border:none;"><i style="color:red;" class="fa fa-heart"></i><span class="tooltipp">add to wishlist</span></button>

												<?php else: ?>
												<button  class="add-to-wishlist" style="background: none; border:none;"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
												<?php endif; ?>
											<?php else: ?>
											<button  class="add-to-wishlist" style="background: none; border:none;"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
											<?php endif; ?>												
										</form>											
										<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
										<button class="quick-view" value="<?php echo e($r_product->id); ?>" data-toggle="modal" data-target="#productModal"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button>
									</div>
							</div>
						</a>
							<div class="add-to-cart">
								<button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to cart</button>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<!-- /product -->

	

				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /Section -->


<?php $__env->stopSection(); ?>




<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/frontend/page/single_product.blade.php ENDPATH**/ ?>