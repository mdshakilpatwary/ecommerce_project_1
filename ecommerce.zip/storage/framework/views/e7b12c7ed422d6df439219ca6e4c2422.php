<?php echo $__env->make('backend.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$id = 1;
 $siteInfo= App\Models\SiteInfo::find($id);
 
 ?>
<?php echo $__env->make('backend.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="loader"></div>
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
	  <!-- header navbar part start  -->
	  <?php echo $__env->make('backend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- header navbar part end  -->
	  <!-- sidebar part start  -->
	  <?php echo $__env->make('backend.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- sidebar part end  -->

    
      <!-- Main Content -->
      <div class="main-content">

	  <?php echo $__env->yieldContent('maincontent'); ?>
		<!-- setting toggle part start  -->
		<?php echo $__env->make('backend.includes.settingToggle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- setting toggle part end -->
      </div>
	  <?php echo $__env->make('backend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
<?php echo $__env->make('backend.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/backend/master.blade.php ENDPATH**/ ?>