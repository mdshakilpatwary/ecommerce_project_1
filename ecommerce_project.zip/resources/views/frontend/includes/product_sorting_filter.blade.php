<div class="store-filter clearfix">
    <div class="store-sort">
    
        <label>
            Sort By:
            <select class="input-select">
                <option class="sort_by_price_high" value="highest_price">Highest Price</option>
                <option class="sort_by_price_low" value="lowest_price">Lowest Price</option>
            </select>
        </label>

        
    </div>
    {{-- <ul class="store-grid">
        <li class="active"><i class="fa fa-th"></i></li>
        <li><a href="#"><i class="fa fa-th-list"></i></a></li>
    </ul>  --}}
</div> 