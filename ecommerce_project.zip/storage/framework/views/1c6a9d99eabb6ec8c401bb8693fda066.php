<?php $__env->startSection('mainbody'); ?>

		<!-- BREADCRUMB -->
		<div id="breadcrumb" class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row" class="">
					<!-- ASIDE -->
					<?php echo $__env->make('frontend.includes.pruduct_sidebar_widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<div id="store"  class="col-md-9">
						<!-- store top filter -->
						<?php echo $__env->make('frontend.includes.product_sorting_filter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
						<!-- /store top filter -->
							<?php if(count($products) > 0): ?>
							<div class="all-filter-product" id="all-filter-product">
								<?php echo $__env->make('frontend.page.search_filter_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
							</div>
							<?php else: ?>
							<h4 class="text-center">Empty Category Product </h4>
							<?php endif; ?>
					</div>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /BREADCRUMB -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row" class="">
					<!-- ASIDE -->
					<?php echo $__env->make('frontend.includes.pruduct_sidebar_widget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					<?php if(count($products) > 0): ?>
					<div class="all-filter-product">
						<?php echo $__env->make('frontend.page.search_filter_product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					</div>
					<?php else: ?>
					<h4 class="text-center">Empty This Category Wise Product Item! </h4>
					<?php endif; ?>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->
		

<?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/frontend/page/category_product.blade.php ENDPATH**/ ?>