

<?php $__env->startSection('maincontent'); ?>




<div class="row">
    <h2 class="">All Role and Permission Here</h2>
    <div class="col-md-10 offset-md-1">
    <div class="card-body">
<?php if(session('success')): ?>

<div class="container alertsuccess">
<div class="alert alert-success alert-dismissible show fade '">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>×</span>
                        </button>
                        <?php echo e(session('success')); ?>

                      </div>
 </div>
</div>
<?php elseif(session('error')): ?>
<div class="container alerterror'">
<div class="alert alert-success alert-dismissible show fade ">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>×</span>
                        </button>
                        <?php echo e(session('error')); ?>

                      </div>
 </div>
</div>

<?php endif; ?>
                    <p class="float-left mb-4">
                        <a class="btn btn-primary text-white" href="<?php echo e(route('role.permission.create')); ?>">Create New Role</a>
                        
                    </p>
                    <div class="clearfix"></div>
                    <div class="table-responsive p-3" style="background: #fff; box-shadow: 0 0 8px #ddd">
                   
                        <table class="table table-striped dataTable no-footer" id="table-1" role="grid" aria-describedby="table-1_info">
                        <thead>
                          <tr role="row">
                            <th class="text-center sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 24.45px;" aria-label="
                              
                            : activate to sort column ascending">
                              #SL
                            </th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Role Name</th>
                          
                           <th class="sorting_desc" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 108.283px;" aria-label="Status: activate to sort column ascending" aria-sort="descending">Permission</th>
                    
                           <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 73.1167px;" aria-label="Action: activate to sort column ascending">Action</th></tr>
                        </thead>
                        <tbody>
                            
                          
                            <?php if(count($roles) > 0): ?>
                            <?php
                          $sl = 1;
                          ?>
                          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr role="row" class="even">
                            <td class="">
                              <?php echo e($sl++); ?>

                            </td>

                            <td>
                            <span style="text-transform: capitalize; font-size: 20px; font-weight: 600"><?php echo e($role->name); ?></span>
                            </td>
                            <td style="width: 300px">
                                <?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rolepermission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge badge-dark mb-1"> <?php echo e($rolepermission->name); ?> </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                           
                            <td>
                              <?php if(Auth::user()->can('role.delete') || Auth::user()->can('role.edit')): ?>
                                <?php if(Auth::user()->can('role.delete')): ?>
                                  <a href="<?php echo e(route('role.permission.delete', $role->id)); ?>" class="btn btn-sm btn-danger text-white "><i class="fa fa-trash"></i></a>
                                <?php endif; ?>
                                <?php if(Auth::user()->can('role.edit')): ?>
                                  <a href="<?php echo e(route('role.permission.edit', $role->id)); ?>" class="btn btn-sm btn-info text-white"><i class="fa fa-edit"></i></a>
                                <?php endif; ?>
                              <?php else: ?>
                               <span class="badge badge-light">No Action</span>
                              <?php endif; ?>

                            </td>
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php else: ?>
                            <tr>
                                <td colspan="5"><p class="bg-danger text-center"> No Data </p></td>
                            </tr>
                            <?php endif; ?>
                         
                        </tbody>
                      </table>
                    </div>
                  </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/backend/role_and_permission/manage.blade.php ENDPATH**/ ?>