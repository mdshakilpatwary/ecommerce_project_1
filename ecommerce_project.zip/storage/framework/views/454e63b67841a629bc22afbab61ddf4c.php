<?php
use App\Models\Category;
$categories = Category::where('cat_status', 1)->get();

?>	
<nav id="navigation">
			<!-- container -->
			<div class="container">
				<!-- responsive-nav -->
				<div id="responsive-nav">
					<!-- NAV -->
					<ul class="main-nav nav navbar-nav">
						<li class="<?php echo e(Route::is('frontend_site*') ? 'active' : ''); ?>"><a href="<?php echo e(url('/')); ?>">Home</a></li>
						<li class="<?php echo e(Route::is('show.all.product*') ? 'active' : ''); ?>"><a href="<?php echo e(route('show.all.product')); ?>">All Product</a></li>
						<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li class="<?php echo e(request()->is('show/category/product/' . $category->id) ? 'active' : ''); ?>"><a href="<?php echo e(route('show.category.product',$category->id)); ?>"><?php echo e($category->cat_name); ?></a></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</ul>
					<!-- /NAV -->
				</div>
				<!-- /responsive-nav -->
			</div>
			<!-- /container -->
		</nav><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/frontend/includes/navbar.blade.php ENDPATH**/ ?>