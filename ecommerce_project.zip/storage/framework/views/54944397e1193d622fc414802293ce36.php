<?php $__env->startSection('maincontent'); ?>
<div class="row mt-2">
<?php if(session('success')): ?>

<div class="container alertsuccess">
<div class="alert alert-success alert-dismissible show fade">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>×</span>
                        </button>
                        <?php echo e(session('success')); ?>

                      </div>
 </div>
</div>
<?php elseif(session('error')): ?>
<div class="container alerterror">
<div class="alert alert-success alert-dismissible show fade">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>×</span>
                        </button>
                        <?php echo e(session('error')); ?>

                      </div>
 </div>
</div>

<?php endif; ?>
    <h2>Add your Product here </h2>
    <div class="col-md-8 col-12 offset-md-2 rounded p-3" style="background: #fff; box-shadow: 0 0 8px #ddd">
        
        <form action="<?php echo e(route('store.product')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
        <div class="row  px-2">
            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="p_code">Product code</label>
                <input type="text" name="p_code" class="form-control" id="" value="<?php echo e(old('p_code')); ?>">
                <?php $__errorArgs = ['p_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="p_name">Product Name</label>
                <input type="text" name="p_name" class="form-control" id="" value="<?php echo e(old('p_name')); ?>">
                <?php $__errorArgs = ['p_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="select_cat">Select Category</label>
               <select name="select_cat" id="" class="form-control select-form">
                <option value="" disabled selected>----Select Category-----</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e(old('select_cat') == $category->id ? 'selected': ''); ?>><?php echo e($category->cat_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
                <?php $__errorArgs = ['select_cat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="select_subcat">Select SubCategory</label>
               <select name="select_subcat" id="" class="form-control select-form">
                <option value="" disabled selected>----Select SubCategory-----</option>
                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($subcategory->id); ?>" <?php echo e(old('select_subcat') == $subcategory->id ? 'selected': ''); ?>><?php echo e($subcategory->subcat_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
                <?php $__errorArgs = ['select_subcat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="select_brand">Select Brand</label>
               <select name="select_brand" id="" class="form-control select-form">
                <option value="" disabled selected>----Select Brand-----</option>
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($brand->id); ?>" <?php echo e(old('select_brand') == $brand->id ? 'selected': ''); ?>><?php echo e($brand->brand_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
                <?php $__errorArgs = ['select_brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
           
            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="select_color">Select Color</label>
                <select  name="select_color[]" id="product-colors" multiple>
                    
                    <?php
                    $allColors = $colors->flatMap(function ($color) {
                        return json_decode($color->color, true);
                    });      
                    $uniqueColors = $allColors->unique('value')->pluck('value');  
                    ?>
                    
                     <?php $__currentLoopData = $uniqueColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($color_value); ?>"><?php echo e($color_value); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    ... more options here ...
                </select>
                <?php $__errorArgs = ['select_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6 col-xl-6 col-12">
                <div class="d-flex justify-content-between"> <label for="select_size">Select Size/kg</label>  <span class="badge badge-light mb-2"><input id="size_d_1_btn" type="checkbox"><label class="mb-0" for="size_d_1_btn">Add size</label></span> <span class="badge badge-light mb-2"><input id="size_d_2_btn" type="checkbox"><label class="mb-0" for="size_d_2_btn">Add kg</label></span> </div>
                <div id="size_d_1">
                    <select  name="select_size[]" id="product-sizes-1" multiple >
                        
                    <?php
                    $allsizes = $sizes->flatMap(function ($size) {
                        return json_decode($size->size, true);
                    });      
                    $uniqueSizes = $allsizes->unique('value')->pluck('value');  
                    ?>
                           <?php $__currentLoopData = $uniqueSizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option   value="<?php echo e($size_value); ?>"><?php echo e($size_value); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                       ... more options here ...
                    </select>
                    
                </div>
                <div id="size_d_2">
                    <select  name="select_size_kg[]" id="product-sizes-2" multiple >
                    
                    <?php
                    $allsizeKg = $kg_data->flatMap(function ($kg) {
                        return json_decode($kg->kg_litter, true);
                    });      
                    $uniqueSizekg = $allsizeKg->unique('value')->pluck('value');  
                    ?>
                        
                           <?php $__currentLoopData = $uniqueSizekg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kg_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option   value="<?php echo e($kg_value); ?>"><?php echo e($kg_value); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                       ... more options here ...
                    </select>
                </div>
                <select  id="product-sizes-disable" class="form-control select-form" >
                    <option value="">Select Size/kg</option>                
                </select>
                <?php $__errorArgs = ['select_sizes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['select_size_kg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="p_price">Product Price</label>
                <input type="floatval" name="p_price" id="" value="<?php echo e(old('p_price')); ?>" class="form-control">

                <?php $__errorArgs = ['p_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="discount_percentage">Discount Percentage</label>
                <input type="floatval" name="discount_percentage" value="<?php echo e(old('discount_percentage')); ?>" id="" class="form-control">

                <?php $__errorArgs = ['discount_percentage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="p_qty">Product quantity</label>
                <input type="floatval" name="p_qty" id="" value="<?php echo e(old('p_qty')); ?>" class="form-control">

                <?php $__errorArgs = ['p_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-12 col-xl-12 col-12">
                <label for="short_description">Short Description</label>
                <textarea class="form-control" name="short_description" id="short_description" cols="5" rows="5" placeholder="Enter Your Product Short Description"></textarea>
                <?php $__errorArgs = ['short_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group ">
                <label for="p_desc">Log Description</label>
               <textarea name="p_desc" class="summernote form-control"><?php echo e(old('p_desc')); ?></textarea>

                <?php $__errorArgs = ['p_desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group col-md-12 col-xl-12 col-12">
                <label for="p_details">Product Details(Optional)</label>
                <textarea class="form-control" name="p_details" id="p_details" cols="5" rows="5" placeholder="Enter Product Details"></textarea>
            </div>

            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="p_image">Product Image</label>
                <input type="file" name="p_image" class="form-control" id="" >
                <?php $__errorArgs = ['p_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             
            </div>
            <div class="form-group col-md-6 col-xl-6 col-12">
                <label for="group_p_image">Product Group Image</label>
                <input type="file" name="group_p_image[]" class="form-control" id="" multiple>
                <?php $__errorArgs = ['group_p_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button class="btn btn-lg btn-success">Add Product</button>
        </div>
        </form>
    </div>
</div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/backend/product/index.blade.php ENDPATH**/ ?>