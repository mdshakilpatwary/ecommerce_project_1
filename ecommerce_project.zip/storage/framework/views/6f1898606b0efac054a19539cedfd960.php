<?php

?>

<div id="aside" class="col-md-3">
    <!-- Category Widget -->
    <div class="aside">
        <h3 class="aside-title">Categories</h3>
        <div class="checkbox-filter">
            <?php $__currentLoopData = $categories=App\Models\Category::where('cat_status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $cat_count =App\Models\Product::catProductCount($category->id);	
            ?>
            <div class="input-checkbox">
                <input type="checkbox" id="category-<?php echo e($category->id); ?>" <?php echo e(request()->is('show/category/product/' . $category->id) ? 'checked' : ''); ?>>
                <label for="category-<?php echo e($category->id); ?>">
                    <span></span>
                    <ul>
                        <li><a href="<?php echo e(route('show.category.product',$category->id)); ?>"><?php echo e($category->cat_name); ?></a> <small>(<?php echo e($cat_count); ?>)</small></li>
                    </ul>
                    
                </label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>

    <!-- aside Widget -->
    <div class="aside">
        <h3 class="aside-title">Price</h3>
        <div class="price-filter">
            <div id="price-slider" ></div>            
            <div class="div" style="display: flex; justify-content: space-around; align-items: center; width: 100%">
                
                <div class="form-group" > <input class="form-control" style="width: 80px; background:none;"  id="price-min"  disabled class="price_range_filter" type="text"></div>                
                <div class="form-group"><button  class="price_range_filter ">Click</button></div>
                <div class="form-group"><input class="form-control" style="width: 80px; background: none;" id="price-max" disabled class="price_range_filter" type="text"> </div>
            </div>
        </div>
    </div>
    <!-- /aside Widget -->
    
    <!-- /aside Widget -->

    <!-- Sub Category Widget -->
    <div class="aside">
        <h3 class="aside-title">Sub Categories</h3>
        <div class="checkbox-filter">
            <?php $__currentLoopData = $subCategories=App\Models\SubCategory::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $sub_cat_count =App\Models\Product::subcatProductCount($subcategory->id);	
            ?>
            <div class="input-checkbox">
                <input type="checkbox" id="category-<?php echo e($subcategory->id); ?>" <?php echo e(request()->is('show/subcategory/product/' . $subcategory->id) ? 'checked' : ''); ?>>
                <label for="category-<?php echo e($subcategory->id); ?>">
                    <span></span>
                    <ul>
                        <li><a href="<?php echo e(route('show.subcategory.product',$subcategory->id)); ?>"><?php echo e($subcategory->subcat_name); ?></a> <small>(<?php echo e($sub_cat_count); ?>)</small></li>
                    </ul>
                    
                </label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
    <!-- /aside Widget -->

    <!-- aside Widget -->
    <div class="aside">
        <h3 class="aside-title">Brand</h3>
        <div class="checkbox-filter">
            <?php $__currentLoopData = $brands =App\Models\Brand::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $brand_count =App\Models\Product::brandProductCount($brand->id);	
            ?>
            <div class="input-checkbox">
                <input type="checkbox" id="brand-<?php echo e($brand->id); ?>" <?php echo e(request()->is('show/brand/product/' . $brand->id) ? 'checked' : ''); ?> >
                <label for="brand-<?php echo e($brand->id); ?>">
                    <span></span>
                    <ul>
                        <li><a href="<?php echo e(route('show.brand.product',$brand->id)); ?>"><?php echo e($brand->brand_name); ?></a> <small>(<?php echo e($brand_count); ?>)</small></li>

                    </ul>
                </label>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <!-- /aside Widget -->

    <!-- aside Widget -->
    <div class="aside">
        <h3 class="aside-title">Top selling</h3>
        <?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($loop->iteration <= 3): ?>
            <div class="product-widget">
                <div class="product-img">
                    <img src="<?php echo e(asset('uploads/product/'.$product->p_image)); ?>" alt="">
                </div>
                <div class="product-body">
                    <p class="product-category"><?php echo e($product->category->cat_name); ?></p>
                    <h3 class="product-name"><a href="<?php echo e(route('single.product',$product->id)); ?>"><?php echo e($product->p_name); ?></a></h3>
                    <h4 class="product-price">&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($product->p_price); ?></del></h4>
                </div>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- /aside Widget -->
</div><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/frontend/includes/pruduct_sidebar_widget.blade.php ENDPATH**/ ?>