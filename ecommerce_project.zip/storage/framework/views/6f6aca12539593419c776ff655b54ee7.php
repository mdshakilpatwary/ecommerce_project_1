<div class="store-filter clearfix">
    <div class="store-sort">
    
        <label>
            Sort By:
            <select class="input-select">
                <option class="sort_by_price_high" value="highest_price">Highest Price</option>
                <option class="sort_by_price_low" value="lowest_price">Lowest Price</option>
            </select>
        </label>

        
    </div>
    
</div> <?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/frontend/includes/product_sorting_filter.blade.php ENDPATH**/ ?>