

<?php $__env->startSection('maincontent'); ?>
<div class="row mt-2">
<?php if(session('success')): ?>

<div class="container alertsuccess">
<div class="alert alert-success alert-dismissible show fade">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>×</span>
                        </button>
                        <?php echo e(session('success')); ?>

                      </div>
 </div>
</div>
<?php elseif(session('error')): ?>
<div class="container alerterror">
<div class="alert alert-success alert-dismissible show fade">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>×</span>
                        </button>
                        <?php echo e(session('error')); ?>

                      </div>
 </div>
</div>

<?php endif; ?>
<div class="col-md-12 pb-5">    
  <h2>Add Role Permision Edit </h2>
</div>
    <div class="col-md-6 offset-md-3  rounded py-3" style="background: #fff; box-shadow: 0 0 8px #ddd">        
        <form action="<?php echo e(route('role.permission.update', $role->id)); ?>" method="POST" >
            <?php echo csrf_field(); ?>
            <div class="form-group ">
                <label for="name">Role Name</label>
                <input type="text" class="form-control" name="name" value="<?php echo e($role->name); ?>" placeholder="Enter role name">


              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="permissions">Permissions</label>

                <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="checkPermissionAll" value="1" <?php echo e(App\Models\User::roleHasPermissions($role, $all_permissions) ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="checkPermissionAll">All</label>
                 <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                    <p class="text-danger "><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <hr>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $permission_groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <?php
                            $permissions = App\Models\User::getpermissionsByGroupName($group->name);
                            $j = 1;
                        ?>
                        
                        <div class="col-3">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" id="<?php echo e($i); ?>Management" value="<?php echo e($group->name); ?>" onclick="checkPermissionByGroup('role-<?php echo e($i); ?>-management-checkbox', this)" <?php echo e(App\Models\User::roleHasPermissions($role, $permissions) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="<?php echo e($i); ?>Management"><?php echo e($group->name); ?></label>
                            </div>
                        </div>

                        <div class="col-9 role-<?php echo e($i); ?>-management-checkbox">
                           
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" onclick="checkSinglePermission('role-<?php echo e($i); ?>-management-checkbox', '<?php echo e($i); ?>Management', <?php echo e(count($permissions)); ?>)" name="permissions[]" <?php echo e($role->hasPermissionTo($permission->name) ? 'checked' : ''); ?> id="checkPermission<?php echo e($permission->id); ?>" value="<?php echo e($permission->name); ?>">
                                    <label class="form-check-label" for="checkPermission<?php echo e($permission->id); ?>"><?php echo e($permission->name); ?></label>
                                </div>
                                <?php  $j++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <br>
                        </div>

                    </div>
                    <?php  $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            
            <button class="btn btn-lg btn-success">Submit</button>
        </form>
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<!-- role and permision js start  -->
<?php $__env->startSection('role_and_parmission_js'); ?>
<script>
    const role_permission = $('#permission').filterMultiSelect();
  </script>
<script>
  /**
       * Checked all  permissions
       */
       $("#checkPermissionAll").click(function(){
           if($(this).is(':checked')){
               // check all the checkbox
               $('input[type=checkbox]').prop('checked', true);
           }else{
               // un check all the checkbox
               $('input[type=checkbox]').prop('checked', false);
           }
       });

       function checkPermissionByGroup(className, checkThis){
          const groupIdName = $("#"+checkThis.id);
          const classCheckBox = $('.'+className+' input');

          if(groupIdName.is(':checked')){
               classCheckBox.prop('checked', true);
           }else{
               classCheckBox.prop('checked', false);
           }
          implementAllChecked();
       }

       function checkSinglePermission(groupClassName, groupID, countTotalPermission) {
          const classCheckbox = $('.'+groupClassName+ ' input');
          const groupIDCheckBox = $("#"+groupID);

          // if there is any occurance where something is not selected then make selected = false
          if($('.'+groupClassName+ ' input:checked').length == countTotalPermission){
              groupIDCheckBox.prop('checked', true);
          }else{
              groupIDCheckBox.prop('checked', false);
          }
          implementAllChecked();
       }

       function implementAllChecked() {
           const countPermissions = <?php echo e(count($all_permissions)); ?>;
           const countPermissionGroups = <?php echo e(count($permission_groups)); ?>;

          //  console.log((countPermissions + countPermissionGroups));
          //  console.log($('input[type="checkbox"]:checked').length);

           if($('input[type="checkbox"]:checked').length >= (countPermissions + countPermissionGroups)){
              $("#checkPermissionAll").prop('checked', true);
          }else{
              $("#checkPermissionAll").prop('checked', false);
          }
       }


</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/backend/role_and_permission/edit.blade.php ENDPATH**/ ?>