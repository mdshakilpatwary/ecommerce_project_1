		<!-- jQuery Plugins -->

		<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.js"></script> 
		<script src="<?php echo e(asset('frontend/assets')); ?>/js/jquery.min.js"></script>
		
		<script src="<?php echo e(asset('frontend/assets')); ?>/js/pagination.js"></script>
		  <!-- JS data table -->
		<script src="<?php echo e(asset('frontend/assets')); ?>/js/bootstrap.min.js"></script>
		<script src="<?php echo e(asset('frontend/assets')); ?>/js/slick.min.js"></script>
		<script src="<?php echo e(asset('frontend/assets')); ?>/js/nouislider.min.js"></script>
		<script src="<?php echo e(asset('frontend/assets')); ?>/js/jquery.zoom.min.js"></script>
		<script src="<?php echo e(asset('frontend/assets')); ?>/js/main.js"></script>

		
<?php echo $__env->yieldContent('customeJavascripti'); ?>
<?php echo $__env->make('frontend.includes.ajax_script_code', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


		

</body>
</html>
<?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/frontend/includes/script.blade.php ENDPATH**/ ?>