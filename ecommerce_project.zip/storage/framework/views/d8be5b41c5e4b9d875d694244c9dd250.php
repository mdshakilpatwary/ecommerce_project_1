<?php $__env->startSection('maincontent'); ?>




<div class="row">
    <h2>All Product Here</h2>
    <div class="col-md-12 ">
    <div class="card-body">
<?php if(session('success')): ?>

<div class="container alertsuccess">
<div class="alert alert-success alert-dismissible show fade '">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>×</span>
                        </button>
                        <?php echo e(session('success')); ?>

                      </div>
 </div>
</div>
<?php elseif(session('error')): ?>
<div class="container alerterror'">
<div class="alert alert-success alert-dismissible show fade ">
                      <div class="alert-body">
                        <button class="close" data-dismiss="alert">
                          <span>×</span>
                        </button>
                        <?php echo e(session('error')); ?>

                      </div>
 </div>
</div>

<?php endif; ?>
                    <div class="table-responsive p-3" style="background: #fff; box-shadow: 0 0 8px #ddd">
                   
                        <table class="table table-striped dataTable no-footer" id="table-1" role="grid" aria-describedby="table-1_info">
                        <thead>
                          <tr role="row">
                            <th class="text-center sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 24.45px;" aria-label="
                              
                            : activate to sort column ascending">
                              #SL
                            </th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Product Name</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Product Code</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Cat_Name</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">SubCat_Name</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">brand</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Color</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Size/Liter/Kg</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Price</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Discount%</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Qty</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Sold Out</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Image</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Group Image</th>
                           
                           <th class="sorting_desc" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 108.283px;" aria-label="Status: activate to sort column ascending" aria-sort="descending">Status</th><th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 73.1167px;" aria-label="Action: activate to sort column ascending">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                            
                          
                            <?php if(count($p_data) > 0): ?>
                            <?php
                          $sl = 1;
                          ?>
                            <?php $__currentLoopData = $p_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr role="row" class="even">
                            <td class="">
                              <?php echo e($sl++); ?>

                            </td>
                            <td><?php echo e($product->p_name); ?></td>
                            <td><?php echo e($product->p_code); ?></td>
                            <td><?php echo e($product->category->cat_name); ?></td>
                            <td><?php echo e($product->subcategory->subcat_name); ?></td>
                            <td><?php echo e($product->brand->brand_name); ?></td>
                            <td>
                              <?php $__currentLoopData = explode("|",$product->color_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <span class="" style="background: grey; color: white; padding: 0 2px; display: inline; border-radius: 5px;"><?php echo e($color); ?></span>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                              <?php if($product->size_id != null): ?>
                                <?php $__currentLoopData = explode("|",$product->size_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span style="background: rgb(47, 47, 47); color: white; padding: 0 2px; display: inline; border-radius: 5px;"><?php echo e($size); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                                <?php $__currentLoopData = explode("|",$product->kg_liter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kg_liter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span style="background: rgb(47, 47, 47); color: white; padding: 0 2px; display: inline; border-radius: 5px;"><?php echo e($kg_liter); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php endif; ?>
                            </td>
                            <td>&#2547;<?php echo e($product->p_price); ?></td>
                            <td><?php echo e($product->discount_percentage); ?>%</td>
                            <td><?php echo e($product->p_qty); ?></td>
                            <td><?php echo e(max($product->p_qty_total - $product->p_qty, 0)); ?></td>
                            <td>
                              <img src="<?php echo e(empty($product->p_image)? asset('uploads/product/empty.png') : asset('uploads/product/'.$product->p_image)); ?>" alt="" width="50" height="50" >
                            </td>
                            <td>
                            <?php $__currentLoopData = explode('|',$product->group_p_image); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gimage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e(empty($gimage)? asset('uploads/product/product_group/empty.png') : asset('uploads/product/product_group/'.$gimage)); ?>" alt="" width="50" height="50" >
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                           
                            
                            
                            <td class="sorting_1">
                              <?php if(Auth::user()->can('product.edit') ): ?>

                                <?php if($product->status == 1): ?>
                                <a href="<?php echo e(route('status.product', $product->id)); ?>" class="badge badge-success badge-shadow">Active</a>
                                <?php else: ?>
                                <a href="<?php echo e(route('status.product', $product->id)); ?>" class="badge badge-danger badge-shadow">Inactive</a>
                                <?php endif; ?>
                              <?php else: ?>
                                <?php if($product->status == 1): ?>
                                <span class="badge badge-success">Active</span>
                                <?php else: ?>
                                <span class="badge badge-warning ">Inactive</span>
                                <?php endif; ?>

                              <?php endif; ?>
                            </td>
                            <td>
                              <?php if(Auth::user()->can('product.edit') || Auth::user()->can('product.delete')): ?>
                                <?php if(Auth::user()->can('product.delete')): ?>
                                <a href="<?php echo e(route('destroy.product', $product->id)); ?>" class="btn btn-sm btn-danger text-white "><i class="fa fa-trash"></i></a>
                                <?php endif; ?>
                                <?php if(Auth::user()->can('product.edit')): ?>
                                <a href="<?php echo e(route('edit.product', $product->id)); ?>" class="btn btn-sm btn-info text-white"><i class="fa fa-edit"></i></a>
                                <?php endif; ?>
                                <?php else: ?>
                              <span class="badge badge-light">No Action</span>
                              <?php endif; ?>
                            </td>
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            <?php else: ?>
                            <tr>
                                <td colspan="14"><p class="bg-danger text-center"> No Data </p></td>
                            </tr>
                            <?php endif; ?>
                         
                        </tbody>
                        <tfoot>
                          <tr role="row">
                            <th class="text-center sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 24.45px;" aria-label="
                              
                            : activate to sort column ascending">
                              #SL
                            </th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Product Name</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Product Code</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Description</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Cat_Name</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">SubCat_Name</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">brand</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Color</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Size</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Price</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Discount%</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Qty</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Image</th>
                            <th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 149.1px;" aria-label="Task Name: activate to sort column ascending">Group Image</th>
                           
                           <th class="sorting_desc" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 108.283px;" aria-label="Status: activate to sort column ascending" aria-sort="descending">Status</th><th class="sorting" tabindex="0" aria-controls="table-1" rowspan="1" colspan="1" style="width: 73.1167px;" aria-label="Action: activate to sort column ascending">Action</th>
                          </tr>
                        </tfoot>
                      </table>
                    </div>
                  </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/backend/product/manage.blade.php ENDPATH**/ ?>