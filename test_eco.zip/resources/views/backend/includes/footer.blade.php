<footer class="main-footer">
        <div class="footer-left">
          <a href="#">All rights reserved {{$siteInfo->name}} </a></a>
        </div>
        <div class="footer-right">
        </div>
</footer>