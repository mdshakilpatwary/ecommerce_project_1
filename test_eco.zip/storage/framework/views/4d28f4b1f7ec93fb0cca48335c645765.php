<?php
use Spatie\Permission\Models\Role;
use App\Models\Category;
$categories = Category::where('cat_status', 1)->get();

$cartArray =cartArray();
$wishlistArray = wishlistArray();

?>	

	<header>
			<!-- TOP HEADER -->
			<div id="top-header">
				<div class="container">
					<ul class="header-links pull-left">
						<li><a href="#"><i class="fa fa-phone"></i> +088<?php echo e($siteInfo->phone); ?></a></li>
						<li><a href="#"><i class="fa fa-envelope-o"></i> <?php echo e($siteInfo->email); ?></a></li>
						<li><a href="#"><i class="fa fa-map-marker"></i> <?php echo e($siteInfo->address); ?></a></li>
					</ul>
					<ul class="header-links pull-right">
						<li><a href="#">&#2547;</i>BDT</a></li>

						<?php if(Auth::user()): ?>
						
							<?php if(Auth::user()->role=='Admin' ): ?>
							<li><a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-user-o"></i> My Account</a></li>

							<?php else: ?>
							<li><a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-user-o"></i> My Account</a></li>
							<?php endif; ?>

						<li><a href="<?php echo e(route('user.logout')); ?>"><i class="fa fa-user-o"></i> Logout</a></li>
						<?php else: ?>
						<li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-user-o"></i> Login</a></li>
						<li><a href="<?php echo e(route('register')); ?>"><i class="fa fa-user-o"></i> Register</a></li>
						<?php endif; ?>
					</ul>
				</div>
			</div>
			<!-- /TOP HEADER -->
		<!-- MAIN HEADER -->
			<div id="header">
				<!-- container -->
				<div class="container">
					<!-- row -->
					<div class="row">
						<!-- LOGO -->
						<div class="col-md-3">
							<div class="header-logo">
								<?php if($siteInfo->main_logo == ''): ?>
								<a href="/" class="logo" >
									<h3 style="color: white; font-size: 40px"><?php echo e($siteInfo->name); ?></h3>
								</a>

								<?php else: ?>
								<a href="/" class="logo" style="">
									<img src="<?php echo e(asset('uploads/info/'.$siteInfo->main_logo)); ?>" style="width: 120px; height: 70px" alt="">
								</a>
								<?php endif; ?>
							</div>
						</div>
						<!-- /LOGO -->

						<!-- SEARCH BAR -->
						<div class="col-md-6">
							<div class="header-search ">
								<form action="<?php echo e(route('product.search')); ?>" method="GET">
									<?php echo csrf_field(); ?>
									<select class="input-select" name="category">
										<option value="All" <?php echo e(request('category')== "All" ? 'selected' : ''); ?>>All Categories</option>
										<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option value="<?php echo e($category->id); ?> " <?php echo e(request('category')== $category->id ? 'selected' : ''); ?>><?php echo e($category->cat_name); ?></option>	
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<input class="input" placeholder="Search here" name="quearyProduct">
									<button class="search-btn">Search</button>
								</form>
							</div>
						</div>
						<!-- /SEARCH BAR -->

						<!-- ACCOUNT -->
						<div class="col-md-3 clearfix">
							<div class="header-ctn">
								<!-- Wishlist -->
								<div class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
										<i class="fa fa-heart-o"></i>
										<span>Your Wishlist</span>
										<?php if(Auth::user()): ?>
										<div class="qty"><?php echo e(count($wishlistArray)); ?></div>
										<?php else: ?>
										<div class="qty">0</div>
										<?php endif; ?>
									</a>
									<div class="cart-dropdown">
										<div class="cart-list">
										<?php if(Auth::user()): ?>
										<?php $__currentLoopData = $wishlistArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="product-widget">
											<div class="product-img">
												
												<img src="<?php echo e(asset('uploads/product/'.$cartdata->p_image)); ?>"  alt="">   
												
											</div>
											<div class="product-body">
												<h3 class="product-name"><a href="<?php echo e(route('single.product',$cartdata->p_id)); ?>"><?php echo e($cartdata->p_name); ?></a></h3>
												<h4 class="product-price">&#2547;<?php echo e($cartdata->p_price); ?></h4>
											</div>
											<a href="<?php echo e(route('product.add_to_wishlist-delete',$cartdata->id)); ?>" class="delete"><i class="fa fa-close"></i></a>
										</div>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
	
										</div>
										<div class="cart-btns">
											<h4 class="text-center">All Wishlist here</h4>
										</div>
									</div>
								</div>
								<!-- /Wishlist -->

								<!-- Cart -->
								<div class="dropdown">
									<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
										<i class="fa fa-shopping-cart"></i>
										<span>Your Cart</span>
										
										<div class="qty"><?php echo e(count($cartArray)); ?></div>
									</a>
									<div class="cart-dropdown">
										<div class="cart-list">
											<?php $__currentLoopData = $cartArray; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<div class="product-widget">
												<div class="product-img">
													<?php if(array_key_exists('p_image', $cartdata['options'])): ?>
													<img src="<?php echo e(asset('uploads/product/'.$cartdata['options']['p_image'])); ?>"  alt="">   
													<?php endif; ?>
												</div>
												<div class="product-body">
													<h3 class="product-name"><a href="#"><?php echo e($cartdata['name']); ?></a></h3>
													<h4 class="product-price"><span class="qty"><?php echo e($cartdata['qty']); ?>x</span>&#2547;<?php echo e($cartdata['price']); ?></h4>
												</div>
												<a href="<?php echo e(route('product.add_to_cart-delete',$cartdata['rowId'])); ?>" class="delete"><i class="fa fa-close"></i></a>
											</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
										</div>
										<div class="cart-summary">
											<small><?php echo e(count($cartArray)); ?> Item(s) selected</small>
											<h5>SUBTOTAL: &#2547;<?php echo e(Cart::subtotal()); ?></h5>
										</div>
										<div class="cart-btns">
											<a href="#">View Cart</a>
											<a href="<?php echo e(route('product.checkout')); ?>">Checkout  <i class="fa fa-arrow-circle-right"></i></a>
										</div>
									</div>
								</div>
								<!-- /Cart -->

								<!-- Menu Toogle -->
								
								<div class="menu-toggle">
									<a href="#">
										<i class="fa fa-bars"></i>
										<span>Menu</span>
									</a>
								</div>
								<!-- /Menu Toogle -->
							</div>
						</div>
						<!-- /ACCOUNT -->
					</div>
					<!-- row -->
				</div>
				<!-- container -->
			</div>
			<!-- /MAIN HEADER -->

		</header><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/frontend/includes/header.blade.php ENDPATH**/ ?>