<?php
use Carbon\Carbon;
?>


<?php $__env->startSection('mainbody'); ?>
			<!-- SECTION -->
			<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					
					<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($loop->iteration <= 3): ?>
					<!-- shop -->
					<div class="col-md-4 col-xl-4 col-lg-4">
						<div class="shop w-100">
							<div class="shop-img ">
								<img class="w-100" src="<?php echo e(asset('uploads/category/'.$category->cat_image)); ?>"  height="200" alt="">
							</div>
							<div class="shop-body">
								<h3><?php echo e($category->cat_name); ?><br>Collection</h3>
								<a href="#" class="cta-btn">Shop now <i class="fa fa-arrow-circle-right"></i></a>
							</div>
						</div>
					</div>
					<!-- /shop -->
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


					
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

					<!-- section title -->
					<div class="col-md-12">
						<div class="section-title">
							<h3 class="title">New Products</h3>
							<div class="section-nav">
								<ul class="section-tab-nav tab-nav">
									<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li class=""><a  href="<?php echo e(route('show.category.product',$category->id)); ?>"><?php echo e($category->cat_name); ?></a></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						</div>
					</div>
					<!-- /section title -->

					<!-- Products tab & slick -->
					<div class="col-md-12">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab1" class="tab-pane active">
									<div class="products-slick" data-nav="#slick-nav-1">
										<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<!-- product -->
										<div class="product">
											<a href="<?php echo e(route('single.product',$product->id)); ?>">
											<div class="product-img">
												<img src="<?php echo e(asset('uploads/product/'.$product->p_image)); ?>"  height="250" alt="">
												<div class="product-label">
													<?php if($product->discount_percentage > 0): ?>
													<span class="sale"><?php echo e($product->discount_percentage); ?>%</span>
													<?php endif; ?>
													<?php if(now()->diffInDays($product->created_at) < 3): ?>
														<span class="new">NEW</span>
													<?php endif; ?>												</div>
											</div>
											
											<div class="product-body">
												
												<p class="product-category"><?php echo e($product->category->cat_name); ?></p>
												<h3 class="product-name"><a href="<?php echo e(route('single.product',$product->id)); ?>"><?php echo e(Illuminate\Support\Str::limit($product->p_name,50,'....')); ?></a></h3>
												<h4 class="product-price" style="padding: 3px 0;">	&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?><del class="product-old-price">	&#2547;<?php echo e($product->p_price); ?></del></h4>
												<div class="product-rating">
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
												</div>
												<?php													
												?>
												<div class="product-btns">
													<form style="display: inline"  action="<?php echo e(route('product.add_to_wishlist')); ?>" method="POST">
													<?php echo csrf_field(); ?>
														<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
														<?php if(Auth::user()): ?>
														<!-- cart wishlist  -->
															<?php if(App\Models\CartWishlist::where('p_id',$product->id)->where('user_id', Auth::user()->id)->first()): ?>
															<button disabled  class="add-to-wishlist" style="background: none; border:none;"><i style="color:red;" class="fa fa-heart"></i><span class="tooltipp">add to wishlist</span></button>
		
															<?php else: ?>
															<button  class="add-to-wishlist" style="background: none; border:none;"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
															<?php endif; ?>
														<?php else: ?>
														<button  class="add-to-wishlist" style="background: none; border:none;"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
														<?php endif; ?>													
													</form>
													<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
													<button class="quick-view" value="<?php echo e($product->id); ?>" data-toggle="modal" data-target="#productModal"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button>
												</div>
												
											</div>
											</a>
											<form action="<?php echo e(route('product.add_to_cart')); ?>" method="POST">
												<?php echo csrf_field(); ?>
											<div class="add-to-cart">
												<input type="hidden" name="quantity" value="1">
												<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
												<?php if($product->p_qty != 0): ?>
												<button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to cart</button>
												<?php else: ?>
												<span class="product-available " style="color:white;">Stock Out</span>
												<?php endif; ?>
											</div>
											</form>
										</div>
										<!-- /product -->
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
									<div id="slick-nav-1" class="products-slick-nav"></div>
								</div>
								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- HOT DEAL SECTION -->
		<div id="hot-deal" class="section " >
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
			<!-- Offer content  condition -->
					<?php if(count($offerData) > 0): ?>

						<?php
							$offerDealData =App\Models\OfferDealContent::findOrFail(1);
							$currentDateTime = Carbon::now();
							$startDate = $offerDealData->offer_duration_start;
							$endDate =$offerDealData->offer_duration_end;
						?>
						<div class="col-md-2 col-lg-3 col-xl-3 d-sm-none offer_deal_image1">
							<img src="<?php echo e(asset('uploads/offer_banner/'.$offerDealData->image1)); ?>" alt="">
						</div>
						<div class="col-md-8 col-lg-6 col-xl-6 col-12 col-sm-12">
							<div class="hot-deal">
					<!-- Offer time counter code condition -->

								<?php if($currentDateTime->between($startDate, $endDate)): ?> 
									<ul class="hot-deal-countdown">
										<li>
											<div>
												<h3 id="offer_deal_day"></h3>
												<span>Days</span>
											</div>
										</li>
										<li>
											<div>
												<h3 id="offer_deal_hour"></h3>
												<span>Hours</span>
											</div>
										</li>
										<li>
											<div>
												<h3 id="offer_deal_minute"></h3>
												<span>Mins</span>
											</div>
										</li>
										<li>
											<div>
												<h3 id="offer_deal_second"></h3>
												<span>Secs</span>
											</div>
										</li>
									</ul>
								<?php else: ?>
									<ul class="hot-deal-countdown">
										<li>
											<div>
												<h3 >0</h3>
												<span>Days</span>
											</div>
										</li>
										<li>
											<div>
												<h3 >0</h3>
												<span>Hours</span>
											</div>
										</li>
										<li>
											<div>
												<h3 >0</h3>
												<span>Mins</span>
											</div>
										</li>
										<li>
											<div>
												<h3 >0</h3>
												<span>Secs</span>
											</div>
										</li>
									</ul>
								<?php endif; ?>
								<h2 class="text-uppercase"><?php echo e($offerDealData->offer_heading); ?></h2>
								<p><?php echo e($offerDealData->offer_content); ?></p>
								<a class="primary-btn cta-btn" href="<?php echo e(route('show.all.product')); ?>">Shop now</a>
							</div>
						</div>
						<div class="col-md-2 col-lg-3 col-xl-3 d-sm-none offer_deal_image2">
							<img src="<?php echo e(asset('uploads/offer_banner/'.$offerDealData->image2)); ?>" alt="">
						</div>
					<?php else: ?>
						<div class="col-md-2 col-lg-3 col-xl-3 d-sm-none offer_deal_image1">
							<img src="<?php echo e(asset('frontend/assets')); ?>/img/product01.png" alt="">
						</div>
						<div class="col-md-8 col-lg-6 col-xl-6 col-12 col-sm-12">
							<div class="hot-deal">
								<ul class="hot-deal-countdown">
									<li>
										<div>
											<h3 >0</h3>
											<span>Days</span>
										</div>
									</li>
									<li>
										<div>
											<h3 >0</h3>
											<span>Hours</span>
										</div>
									</li>
									<li>
										<div>
											<h3 >0</h3>
											<span>Mins</span>
										</div>
									</li>
									<li>
										<div>
											<h3 >0</h3>
											<span>Secs</span>
										</div>
									</li>
								</ul>
								<h2 class="text-uppercase">hot deal this week</h2>
								<p>New Collection Up to 50% OFF;</p>
								<a class="primary-btn cta-btn" href="<?php echo e(route('show.all.product')); ?>">Shop now</a>
							</div>
						</div>
						<div class="col-md-2 col-lg-3 col-xl-3 d-sm-none offer_deal_image2">
							<img src="<?php echo e(asset('frontend/assets')); ?>/img/product02.png" alt="">
						</div>
					<?php endif; ?>
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /HOT DEAL SECTION -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">

					<!-- section title -->
					
					<!-- /section title -->

					<!-- Products tab & slick -->
					<div class="col-md-12">
						<div class="row">
							<div class="products-tabs">
								<!-- tab -->
								<div id="tab2" class="tab-pane fade in active">
									<div class="products-slick" data-nav="#slick-nav-2">
										<?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<!-- product -->
										<div class="product">
											<a href="<?php echo e(route('single.product',$product->id)); ?>">
											<div class="product-img">
												<img src="<?php echo e(asset('uploads/product/'.$product->p_image)); ?>" height="250" alt="">
												<div class="product-label">
													<?php if($product->discount_percentage > 0): ?>
													<span class="sale"><?php echo e($product->discount_percentage); ?>%</span>
													<?php endif; ?>
													<?php if(now()->diffInDays($product->created_at) < 3): ?>
														<span class="new">NEW</span>
													<?php endif; ?>
												</div>
											</div>
											<div class="product-body">
												<p class="product-category"><?php echo e($product->category->cat_name); ?></p>
												<h3 class="product-name"><a href="<?php echo e(route('single.product',$product->id)); ?>"><?php echo e(Illuminate\Support\Str::limit($product->p_name,50,'....')); ?></a></h3>
												<h4 class="product-price" style="padding: 5px 0;">&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($product->p_price); ?></del></h4>
												<div class="product-rating">
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
													<i class="fa fa-star"></i>
												</div>
												<div class="product-btns">
													<form style="display: inline"  action="<?php echo e(route('product.add_to_wishlist')); ?>" method="POST">
														<?php echo csrf_field(); ?>
															<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
															<?php if(Auth::user()): ?>
															<!-- cart wishlist -->
																<?php if(App\Models\CartWishlist::where('p_id',$product->id)->where('user_id', Auth::user()->id)->first()): ?>
																<button disabled  class="add-to-wishlist" style="background: none; border:none;"><i style="color:red;" class="fa fa-heart"></i><span class="tooltipp">add to wishlist</span></button>
			
																<?php else: ?>
																<button  class="add-to-wishlist" style="background: none; border:none;"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
																<?php endif; ?>
															<?php else: ?>
															<button  class="add-to-wishlist" style="background: none; border:none;"><i class="fa fa-heart-o"></i><span class="tooltipp">add to wishlist</span></button>
															<?php endif; ?>												</form>													<button class="add-to-compare"><i class="fa fa-exchange"></i><span class="tooltipp">add to compare</span></button>
															<button class="quick-view" value="<?php echo e($product->id); ?>" data-toggle="modal" data-target="#productModal"><i class="fa fa-eye"></i><span class="tooltipp">quick view</span></button>
														</div>
											</div>
										</a>
										<form action="<?php echo e(route('product.add_to_cart')); ?>" method="POST">
											<?php echo csrf_field(); ?>
										<div class="add-to-cart">
											<input type="hidden" name="quantity" value="1">
											<input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
											<?php if($product->p_qty != 0): ?>
											<button class="add-to-cart-btn"><i class="fa fa-shopping-cart"></i> add to cart</button>
											<?php else: ?>
											<span class="product-available " style="color:white;">Stock Out</span>
											<?php endif; ?>										</div>
										</form>
										</div>
										<!-- /product -->
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</div>
									<div id="slick-nav-2" class="products-slick-nav"></div>
								</div>
								<!-- /tab -->
							</div>
						</div>
					</div>
					<!-- /Products tab & slick -->
				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->

		<!-- SECTION -->
		<div class="section">
			<!-- container -->
			<div class="container">
				<!-- row -->
				<div class="row">
					<div class="col-md-4 col-xs-6">
						<div class="section-title">
							<h4 class="title">Top selling</h4>
							<div class="section-nav">
								<div id="slick-nav-3" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-3">
							<div>
								<!-- product widget -->
								<?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($loop->iteration <= 3): ?>
								<div class="product-widget">
									<div class="product-img">
										<img src="<?php echo e(asset('uploads/product/'.$product->p_image)); ?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category"><?php echo e($product->category->cat_name); ?></p>
										<h3 class="product-name"><a href="<?php echo e(route('single.product',$product->id)); ?>"><?php echo e($product->p_name); ?></a></h3>
										<h4 class="product-price">&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($product->p_price); ?></del></h4>
									</div>
								</div>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<!-- /product widget -->


							</div>

							<div>
								<!-- product widget -->
								<?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($loop->iteration <= 3): ?>
								<div class="product-widget">
									<div class="product-img">
										<img src="<?php echo e(asset('uploads/product/'.$product->p_image)); ?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category"><?php echo e($product->category->cat_name); ?></p>
										<h3 class="product-name"><a href="<?php echo e(route('single.product',$product->id)); ?>"><?php echo e($product->p_name); ?></a></h3>
										<h4 class="product-price">&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($product->p_price); ?></del></h4>
									</div>
								</div>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<!-- /product widget -->

	
	
							</div>
						</div>
					</div>

					<div class="col-md-4 col-xs-6">
						<div class="section-title">
							<h4 class="title">Selling</h4>
							<div class="section-nav">
								<div id="slick-nav-4" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-4">
							<div>
								<!-- product widget -->
								<?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($loop->iteration <= 3): ?>
								<div class="product-widget">
									<div class="product-img">
										<img src="<?php echo e(asset('uploads/product/'.$product->p_image)); ?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category"><?php echo e($product->category->cat_name); ?></p>
										<h3 class="product-name"><a href="<?php echo e(route('single.product',$product->id)); ?>"><?php echo e($product->p_name); ?></a></h3>
										<h4 class="product-price">&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($product->p_price); ?></del></h4>
									</div>
								</div>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<!-- /product widget -->


							</div>

							<div>
								<!-- product widget -->
								<?php $__currentLoopData = $topProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($loop->iteration <= 3): ?>
								<div class="product-widget">
									<div class="product-img">
										<img src="<?php echo e(asset('uploads/product/'.$product->p_image)); ?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category"><?php echo e($product->category->cat_name); ?></p>
										<h3 class="product-name"><a href="<?php echo e(route('single.product',$product->id)); ?>"><?php echo e($product->p_name); ?></a></h3>
										<h4 class="product-price">&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($product->p_price); ?></del></h4>
									</div>
								</div>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<!-- /product widget -->

	
	
							</div>
						</div>
					</div>

					<div class="clearfix visible-sm visible-xs"></div>

					<div class="col-md-4 col-xs-6">
						<div class="section-title">
							<h4 class="title">New Product</h4>
							<div class="section-nav">
								<div id="slick-nav-5" class="products-slick-nav"></div>
							</div>
						</div>

						<div class="products-widget-slick" data-nav="#slick-nav-5">
							<div>
								<!-- product widget -->
								<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($loop->iteration <= 3): ?>
								<div class="product-widget">
									<div class="product-img">
										<img src="<?php echo e(asset('uploads/product/'.$product->p_image)); ?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category"><?php echo e($product->category->cat_name); ?></p>
										<h3 class="product-name"><a href="<?php echo e(route('single.product',$product->id)); ?>"><?php echo e($product->p_name); ?></a></h3>
										<h4 class="product-price">&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($product->p_price); ?></del></h4>
									</div>
								</div>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<!-- /product widget -->


							</div>

							<div>
								<!-- product widget -->
								<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php if($loop->iteration <= 3): ?>
								<div class="product-widget">
									<div class="product-img">
										<img src="<?php echo e(asset('uploads/product/'.$product->p_image)); ?>" alt="">
									</div>
									<div class="product-body">
										<p class="product-category"><?php echo e($product->category->cat_name); ?></p>
										<h3 class="product-name"><a href="<?php echo e(route('single.product',$product->id)); ?>"><?php echo e($product->p_name); ?></a></h3>
										<h4 class="product-price">&#2547;<?php echo e($product->p_price -($product->p_price*($product->discount_percentage/100))); ?> <del class="product-old-price">&#2547;<?php echo e($product->p_price); ?></del></h4>
									</div>
								</div>
								<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<!-- /product widget -->

	
	
							</div>
						</div>
					</div>

				</div>
				<!-- /row -->
			</div>
			<!-- /container -->
		</div>
		<!-- /SECTION -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/frontend/welcome.blade.php ENDPATH**/ ?>