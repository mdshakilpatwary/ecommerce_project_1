
<?php echo $__env->make('frontend.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
$id = 1;
 $siteInfo= App\Models\SiteInfo::find($id);
 
?>
 
		<!-- HEADER -->
<?php echo $__env->make('frontend.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<!-- /HEADER -->

		<!-- NAVIGATION -->
<?php echo $__env->make('frontend.includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- /NAVIGATION -->

<main>
	

<?php echo $__env->yieldContent('mainbody'); ?>

</main>

		<!-- NEWSLETTER -->
<?php echo $__env->make('frontend.includes.nawsletter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<!-- /NEWSLETTER -->
		<!-- modal -->
<?php echo $__env->make('frontend.includes.quick_view_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


		<!-- FOOTER -->

<?php echo $__env->make('frontend.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- /FOOTER -->

<?php echo $__env->make('frontend.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH F:\Practice programming file\local server xampp\htdocs\ecommerce_project_1\resources\views/frontend/master.blade.php ENDPATH**/ ?>